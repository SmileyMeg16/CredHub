var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const { MongoClient } = require('mongodb');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

// MongoDB Connection URI
const mongoUrl = "mongodb+srv://credhub57:CredHub*2024@credhub.dglqyvp.mongodb.net/?retryWrites=true&w=majority&appName=CredHub";

// Utility Functions
function sanitizeAndValidateDate(dateString) {
    const trimmedDate = dateString.trim();
    const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/;
    return dateRegex.test(trimmedDate) ? trimmedDate : null;
}

function sanitizeAndEscapeQuotes(inputString) {
    return inputString.replace(/'/g, "''");
}

// Express application setup...
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

// POST /validateAge
app.post('/validateAge', async (req, res) => {
    let client;
    try {
        client = new MongoClient(mongoUrl, { useNewUrlParser: true, useUnifiedTopology: true });
        await client.connect();
        const db = client.db('WyoID');
        const collection = db.collection('idData');

        // Consistently use `birthDate` and `expirationDate` based on your input structure
        let { firstName, lastName, birthDate, dlNumber, expirationDate, state } = req.body;

        birthDate = sanitizeAndValidateDate(birthDate);
        expirationDate = sanitizeAndValidateDate(expirationDate);

        if (!birthDate || !expirationDate) {
            return res.status(400).send('Invalid date format');
        }

        // Ensure field names in the query match those in your MongoDB collection
        const query = {
            "First Name": firstName,
            "Last Name": lastName,
            "Birth Date": birthDate,
            "DL Number": dlNumber,
            "Experation Date": expirationDate,
            "State": state
        };

        const record = await collection.findOne(query);
        res.send(record ? 'true' : 'false');
    } catch (error) {
        console.error("Error connecting to MongoDB:", error);
        res.status(500).send('Internal server error');
    } finally {
        if (client) {
            await client.close();
        }
    }
});

// POST /validateDegree
app.post('/validateDegree', async (req, res) => {
  let client;
  try {
      client = new MongoClient(mongoUrl, { useNewUrlParser: true, useUnifiedTopology: true });
      await client.connect();
      const db = client.db('UWDegree');
      const collection = db.collection('DegreeData');

      // Consistently use `birthDate` and `expirationDate` based on your input structure
      let { firstName, lastName, birthDate, schoolID, university, degreeType, yearAchieved, degreeAwarded } = req.body;

      birthDate = sanitizeAndValidateDate(birthDate);

      if (!birthDate) {
          return res.status(400).send('Invalid date format');
      }

      // Ensure field names in the query match those in your MongoDB collection
      const query = {
          "First Name": firstName,
          "Last Name": lastName,
          "Birth Date": birthDate,
          "University": university,
          "SchoolID": schoolID,
          "DegreeType": degreeType,
          "DegreeAwarded": degreeAwarded,
          "YearAchived": yearAchieved
      };

      const record = await collection.findOne(query);
      res.send(record ? 'true' : 'false');
  } catch (error) {
      console.error("Error connecting to MongoDB:", error);
      res.status(500).send('Internal server error');
  } finally {
      if (client) {
          await client.close();
      }
  }
});

// Error handling...
app.use(function(req, res, next) {
    next(createError(404));
});

app.use(function(err, req, res, next) {
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};
    res.status(err.status || 500);
    res.render('error');
});

module.exports = app;
