package com.example.credhub.ui.ageValidated;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.credhub.MainActivity;
import com.example.credhub.R;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;


public class ageValidated extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age_validated);

        ImageButton backButton = findViewById(R.id.imageButton4);
        ImageView userImageView = findViewById(R.id.imagePerson);
        ImageView approveOrNotImageView = findViewById(R.id.approveornot);

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(ageValidated.this, MainActivity.class);
            startActivity(intent);
        });

        populateUserData(userImageView, approveOrNotImageView);
    }

    private void populateUserData(final ImageView userImageView, final ImageView approveOrNotImageView) {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();

            // Fetching the age validation status from the AgeValidation table
            DatabaseReference ageValidationRef = FirebaseDatabase.getInstance().getReference().child("AgeValidation").child(userId);
            ageValidationRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        Boolean ageValidated = dataSnapshot.child("ageValidated").getValue(Boolean.class);
                        if (Boolean.TRUE.equals(ageValidated)) {
                            approveOrNotImageView.setImageResource(R.drawable.checkmark); // Display green checkmark
                        } else {
                            approveOrNotImageView.setImageResource(R.drawable.redx); // Display red X
                        }
                        approveOrNotImageView.setVisibility(View.VISIBLE);
                    } else {
                        showToast("Age validation data not found.");
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    showToast("Failed to retrieve age validation status.");
                }
            });

            // Fetching the user image from Firebase Storage
            StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("user_images/" + userId);
            storageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                Glide.with(ageValidated.this)
                        .load(uri)
                        .placeholder(R.mipmap.image_logo)
                        .error(R.mipmap.image_logo)
                        .into(userImageView);
            }).addOnFailureListener(exception -> {
                // Handle any errors in fetching the image, such as file not found
                showToast("Failed to retrieve user image.");
            });
        }
    }

    private void showToast(String message) {
        runOnUiThread(() -> Toast.makeText(ageValidated.this, message, Toast.LENGTH_SHORT).show());
    }
}
