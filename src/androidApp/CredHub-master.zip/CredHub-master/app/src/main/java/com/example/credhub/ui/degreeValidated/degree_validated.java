package com.example.credhub.ui.degreeValidated;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.example.credhub.MainActivity;
import com.example.credhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class degree_validated extends AppCompatActivity {

    private TextView textUniversity, textDegreeType, textDegree, textYear;
    private ImageView imageValidationStatus; // ImageView for showing the validation status

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_degree_validated);

        // Initialize TextViews
        textUniversity = findViewById(R.id.textUniversity);
        textDegreeType = findViewById(R.id.textDegreeType);
        textDegree = findViewById(R.id.textDegree);
        textYear = findViewById(R.id.textYear);
        // Initialize ImageView for showing validation status
        imageValidationStatus = findViewById(R.id.imageValidationStatus);

        ImageButton backButton = findViewById(R.id.imageButton4);
        // Set OnClickListener for the ImageButton to navigate back to the main activity
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(degree_validated.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Populate user data when activity is created
        populateUserData();
    }

    private void populateUserData() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();

            // Get reference to the degree validation node in Firebase Realtime Database
            DatabaseReference degreeValidationRef = FirebaseDatabase.getInstance().getReference().child("DegreeValidation").child(userId);

            // Read user data from Firebase Realtime Database
            degreeValidationRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        // Populate views with user data
                        String university = dataSnapshot.child("university").getValue(String.class);
                        String degreeType = dataSnapshot.child("degreeType").getValue(String.class);
                        String degree = dataSnapshot.child("degreeAwarded").getValue(String.class);
                        String year = dataSnapshot.child("yearAchieved").getValue(String.class);
                        Boolean degreeValidated = dataSnapshot.child("degreeValidated").getValue(Boolean.class);

                        // Set user data to corresponding views
                        textUniversity.setText(university);
                        textDegreeType.setText(degreeType);
                        textDegree.setText(degree);
                        textYear.setText(year);

                        // Update the validation status image based on degreeValidated
                        if (Boolean.TRUE.equals(degreeValidated)) {
                            imageValidationStatus.setImageResource(R.drawable.checkmark); // Check mark image
                        } else {
                            imageValidationStatus.setImageResource(R.drawable.redx); // Red X image
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle database error
                }
            });
        }
    }
}
