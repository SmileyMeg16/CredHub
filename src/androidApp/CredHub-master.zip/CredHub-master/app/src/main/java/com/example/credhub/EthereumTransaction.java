package com.example.credhub;

import java.util.concurrent.CompletableFuture;
import java.io.IOException;

import org.web3j.crypto.Credentials;
import org.web3j.crypto.RawTransaction;
import org.web3j.crypto.TransactionEncoder;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.methods.response.EthSendTransaction;
import org.web3j.protocol.http.HttpService;
import org.web3j.utils.Convert;
import org.web3j.utils.Numeric;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import org.web3j.protocol.core.methods.response.EthGetBalance;
import org.web3j.protocol.core.methods.response.EthGetTransactionCount;
import org.web3j.protocol.core.DefaultBlockParameterName;

public class EthereumTransaction {

    private static final String API_KEY = "02d7ba07-387c-5c55-a0fa-84ef71ff5d74";
    private static final String PRIVATE_KEY = "4455944b5876fd35c3f8aa72e18120c96fc595a5584c9aba3b327b471b4fbb17";
    private static final String WALLET_ADDRESS = "0xE80983554a7A91FeB37E63e57578dE12DBc3C749";
    private static final BigInteger CHAIN_ID = BigInteger.valueOf(11155111);
    private static final String NODE_URL = "https://go.getblock.io/ad3d75f39b6a4430b98b037c0ab0a826";
    //BigInteger nonce = getNonce(WALLET_ADDRESS);
    private static final BigInteger gasPrice = BigInteger.ZERO;
    private static final BigInteger gasLimit = BigInteger.valueOf(1000000);

    public static void transact(String dataToBlockchain) {

        CompletableFuture.runAsync(() -> {
            try {

                Web3j web3j = Web3j.build(new HttpService(NODE_URL));

                // Generate new address and private key
                // Credentials credentials = Credentials.create(WALLET_ADDRESS);
                Credentials credentials = Credentials.create(PRIVATE_KEY);
                System.out.println("Address: " + credentials.getAddress());
                System.out.println("Wallet Address: " + credentials.getEcKeyPair().getPrivateKey().toString(16));

                // Get balance and print
                try {
                    EthGetBalance balanceWei = web3j.ethGetBalance(WALLET_ADDRESS, org.web3j.protocol.core.DefaultBlockParameterName.LATEST).sendAsync().get();
                    BigDecimal balanceInEther = Convert.toWei(balanceWei.getBalance().toString(), Convert.Unit.ETHER);
                    System.out.println("Balance: " + balanceInEther);
                } catch (Exception e) {
                    System.out.println("Error printing balance.");
                    e.printStackTrace();
                }

                BigInteger nonce = web3j.ethGetTransactionCount(
                                credentials.getAddress(), org.web3j.protocol.core.DefaultBlockParameterName.PENDING)
                        .send()
                        .getTransactionCount();

                BigInteger value = Convert.toWei("0", Convert.Unit.ETHER).toBigInteger();
                String hexData = Numeric.toHexString(dataToBlockchain.getBytes(StandardCharsets.UTF_8));

                // Send transaction
                RawTransaction rawTransaction = RawTransaction.createTransaction(
                        nonce,
                        gasPrice,
                        gasLimit,
                        WALLET_ADDRESS,
                        value,
                        hexData);

                //BigInteger chainId = BigInteger.valueOf(CHAIN_ID);
                long chainId = CHAIN_ID.longValue();

                //RawTransaction rawTransaction = RawTransaction.createTransaction(
                //        nonce, gasPrice, gasLimit, toAddress, value, data);

                // Sign the transaction
                byte[] signedMessage = TransactionEncoder.signMessage(rawTransaction, chainId, credentials);
                String hexValue = Numeric.toHexString(signedMessage);

                // Send the signed transaction
                EthSendTransaction sendTransactionResponse = web3j.ethSendRawTransaction(hexValue).send();

                if (sendTransactionResponse.hasError()) {
                    System.out.println("Transaction Error: " + sendTransactionResponse.getError().getMessage());
                } else {
                    System.out.println("Transaction Successful: " + sendTransactionResponse.getTransactionHash());
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
