package com.example.credhub.ui.slideshow;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.bumptech.glide.Glide;
import com.example.credhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SlideshowFragment extends Fragment {

    private ImageView imagePerson;
    private TextView textFullName, textEmail, textPhoneNumber;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);

        imagePerson = root.findViewById(R.id.imagePerson);
        textFullName = root.findViewById(R.id.textFullName);
        textEmail = root.findViewById(R.id.textEmail);
        textPhoneNumber = root.findViewById(R.id.textPhoneNumber);

        // Retrieve user data including image URL and populate views
        populateUserData();

        return root;
    }

    private void populateUserData() {
        // Get current user from Firebase Authentication
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            // User is signed in, retrieve user ID
            String userId = currentUser.getUid();

            // Get reference to the user node in Firebase Realtime Database
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference().child("Users").child(userId);

            // Read user data from Firebase Realtime Database
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // Check if user data exists
                    if (dataSnapshot.exists()) {
                        // Populate views with user data
                        String fullName = dataSnapshot.child("firstName").getValue(String.class) + " " + dataSnapshot.child("lastName").getValue(String.class);
                        String email = dataSnapshot.child("email").getValue(String.class);
                        String phoneNumber = dataSnapshot.child("phoneNumber").getValue(String.class);
                        String imageUrl = dataSnapshot.child("imageUri").getValue(String.class);

                        // Set user data to corresponding views
                        textFullName.setText(fullName);
                        textEmail.setText(email);
                        textPhoneNumber.setText(phoneNumber);

                        // Load and display user image using Glide
                        Glide.with(getContext())
                                .load(imageUrl)
                                .placeholder(R.mipmap.image_logo) // Placeholder image while loading
                                .error(R.mipmap.image_logo) // Error image if loading fails
                                .into(imagePerson);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle database error
                }
            });
        }
    }
}
