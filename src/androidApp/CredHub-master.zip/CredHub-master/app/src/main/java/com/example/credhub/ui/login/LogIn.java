package com.example.credhub.ui.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.credhub.R;
import com.example.credhub.mainload;
import com.example.credhub.VerificationActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;

public class LogIn extends AppCompatActivity {

    private EditText emailEditText;
    private EditText passwordEditText;
    private FirebaseAuth mAuth;
    private DatabaseReference userCodesRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        mAuth = FirebaseAuth.getInstance();
        userCodesRef = FirebaseDatabase.getInstance().getReference("UserCodes");

        // Initialize EditText fields
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        // Find the ImageButton by its id
        ImageButton backButton = findViewById(R.id.imageButton4);
        // Set OnClickListener for the ImageButton
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the mainload activity
                Intent intent = new Intent(LogIn.this, mainload.class);
                startActivity(intent);
            }
        });

        Button signinButton = findViewById(R.id.signinbutton);
        // Set OnClickListener for the sign-in button
        signinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered email and password
                String email = emailEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Authenticate user using Firebase Authentication
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(LogIn.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // User successfully signed in, send verification code via email
                                    sendCodeToEmail();
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(LogIn.this, "Email or Password incorrect.",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }

    // Method to send the verification code to the user's email
    private void sendCodeToEmail() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            // Get the current user's email and ID
            final String email = user.getEmail();
            final String userID = user.getUid();

            // Generate a random 6-digit code
            final String code = generateRandomCode();

            // Store the code under the user's ID in the database
            userCodesRef.child(userID).setValue(code)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                // Code successfully stored in the database, send email
                                sendEmail(email, code);
                            } else {
                                Toast.makeText(LogIn.this, "Failed to send verification code.",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }

    // Method to send the code via email
    private void sendEmail(String email, String code) {
        // For simplicity, we'll just display the code in a Toast message.
        Toast.makeText(LogIn.this, "Verification code sent to " + email + ": " + code,
                Toast.LENGTH_LONG).show();

        // Navigate to verification activity
        Intent intent = new Intent(LogIn.this, VerificationActivity.class);
        // Pass the generated code to the VerificationActivity
        intent.putExtra("verification_code", code);
        startActivity(intent);
    }

    // Method to generate random 6-digit code
    private String generateRandomCode() {
        Random random = new Random();
        int randomInt = random.nextInt(900000) + 100000;
        return String.valueOf(randomInt);
    }
}
